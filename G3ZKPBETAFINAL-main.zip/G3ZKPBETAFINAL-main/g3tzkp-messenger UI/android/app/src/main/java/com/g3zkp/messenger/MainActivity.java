package com.g3zkp.messenger;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
